# Demo UI (Solution Playground) SDK

`@specificity/playground` is the screen a person logs into to try a built
solution and decide whether it is good enough for production. It is written
once here and deployed with every solution built from a Precord, beside the
solution's case management list and KPI dashboard. It implements component
**C6-3** of the build pipeline against
[Requirements v5](../docs/Specificity-DemoUI-Requirements-v5-package/Specificity-DemoUI-Playground-Requirements-v5.md)
and the wireframes beside it.

Eight screens, one rail: **Overview · Agents · Walk a case · Performance ·
KPIs · Solution Status · Next steps · Sign-off.** Built on the Specificity
design system (light theme, `dense` scale), IBM Plex Mono for chrome, cyan for
what is interactive, magenta for what is human.

## What the library is

Three layers, all exported from the package root:

| Layer | What it holds | Where |
| --- | --- | --- |
| **Model** | The typed data the screens render (`SolutionSpec`, `Walk`, `EvalResults`, …), the closed vocabularies the requirements fix (the twenty pill words of GC-5, the four autonomy tiers, the six fidelity labels), wording and date helpers, and the pure derivations (verdicts, open items, the release rule) | `src/model/` |
| **Adapter** | `PlaygroundAdapter` — the seam a solution implements so the screens can read the build and drive the solution's own runtime (R-4). Two implementations ship: `createHttpAdapter` over a JSON contract, and `createMemoryAdapter` as the reference implementation for fixtures and tests | `src/adapters/` |
| **UI** | `<Playground>` and `mountPlayground()`, the eight screens, the embedded `ReviewScreen`, and the primitives (`Pill`, `Tag`, `FidelityChip`, `StatTile`, …) | `src/ui/`, `src/Playground.tsx` |

Plus `readSolutionSpec()`, which turns the Precord's files (`context/*.csv`,
`reimagined_process_graph.mmd`, the parsed `spec/*.yaml`, `open_items.csv`,
`deviations.csv`, input schemas) into a `SolutionSpec`, and two fixtures:
`claimsTriage` (the solution the wireframes show) and `emptySolution` (the A8
reference: a Precord and nothing else).

## Use it in a solution

**Building a solution against this?** Read
[INTEGRATION.md](INTEGRATION.md) — the brief for the coding assistant wiring the
playground into a built solution: how to install it, the routes to serve, and
the rules that must hold.

The package is not on a public registry. Build a tarball with `npm pack` and
depend on the file, or depend on this folder directly — its `prepare` script
builds `dist/` at install time:

```jsonc
"dependencies": {
  "@specificity/playground": "file:vendor/specificity-playground-0.1.0.tgz",
  "react": "^19.0.0",
  "react-dom": "^19.0.0"
}
```

React 19 is a peer dependency; the bundle carries no copy of it.

```tsx
import { Playground, createHttpAdapter } from '@specificity/playground'
import '@specificity/playground/styles.css'

const adapter = createHttpAdapter({ baseUrl: '/playground' })

export function PlaygroundPage() {
  return <Playground adapter={adapter} routing="hash" />
}
```

Or, from a page that is not a React app:

```ts
import { mountPlayground, createHttpAdapter } from '@specificity/playground'
mountPlayground(document.getElementById('playground')!, { adapter: createHttpAdapter() })
```

The user's type (subject-matter expert or technical) comes from the adapter's
session and sets the landing screen — Overview or Solution Status — and the
role in the rail, nothing else (§2, AC-2). Pass `initialScreen` to override the
landing screen, and `kpiDashboard` to hand in the standalone KPI surface
(KP-3) as a React node once the dashboard component exists.

### Serve the HTTP contract

`createHttpAdapter` calls the routes listed at the top of
[`src/adapters/http.ts`](src/adapters/http.ts) under `baseUrl`. Every wire shape
is a type from `src/model/types.ts`, unchanged. A route the solution has not
built yet may answer 404; the adapter turns that into the empty value and the
screen shows *no data yet* (R-1). Uploads travel as `multipart/form-data` with
the files under `files` and the request under a `request` JSON part.

The routes that must reach the solution's own runtime, never a demo path (R-4):
`POST /agents/:id/runs`, `POST /walks`, `POST /walks/:id/step`,
`POST /walks/:id/run`, `POST /walks/:id/decisions` (through the review API),
`POST /status/probe` (the same scoped no-op call the pipeline uses),
`POST /evals/run`, `POST /next-steps/send` (Ask Specificity Actions),
`POST /sign-off` (the build record).

### Or implement the adapter in-process

`PlaygroundAdapter` in [`src/model/adapter.ts`](src/model/adapter.ts) is grouped
by screen. `createMemoryAdapter` in [`src/adapters/memory.ts`](src/adapters/memory.ts)
implements every method over a `PlaygroundSnapshot` and is the worked example
to read first. Its runtime is a lookup of canned outputs per synthetic case;
that is deliberately not an agent, and a deployment must not keep it.

### Build the specification from the Precord

```ts
import { readSolutionSpec } from '@specificity/playground'

const spec = readSolutionSpec(
  {
    'context/process_step_table.csv': text1,
    'context/reimagined_process_graph.mmd': text2,
    'context/agent_specifications.csv': text3,
    'context/ontology_nodes.csv': text4,
    'context/kpi_board_definition.csv': text5,
    'spec/agents.yaml': parsedAgents,        // parsed by the host; this library carries no YAML reader
    'spec/checkpoints.yaml': parsedCheckpoints,
    'spec/tools.yaml': parsedTools,
    inbound: [{ id: 'mailbox', name: 'Claims mailbox' }],
    'spec/open_items.csv': text6,
    'spec/deviations.csv': text7,
    inputSchemas: { 'BLK-01': schemaJson },
    evalsSource: '2025 closed claims',
  },
  { buildId: '41c9', precordVersion: 7, builtAt: '2026-09-09T18:04:00', solutionName: 'Claims Triage', systemFidelity: 'mock system' },
)
```

Field names follow the projectors in `backend/app/agents/e2/` (`agent_id`,
`autonomy`, `serves_steps`, `checkpoint_id`, `mode`, `shown`, `actions`,
`capture`, `tool_id`, `kind`, `endpoint`). A missing file yields an empty part,
never a default.

## The rules the code enforces

- **R-1** — every model field that can be absent is optional; every screen has
  an explicit empty state; a metric with no source reads *no data yet*; a
  not-built agent reads `NOT BUILT` with its reason. `emptySolution` and the A8
  test in `test/screens.test.tsx` hold this.
- **R-2 / GC-4** — `Fidelity` is a closed union and `FidelityChip` is on every
  output and figure.
- **GC-5** — `Pill` takes a `PillWord`, a union of exactly the twenty words; the
  A9 test walks every screen and asserts every rendered pill.
- **GC-6** — `AutonomyTag` maps the Precord's tier keys to the four plain
  phrases; the human review point is the magenta `Human` tag.
- **R-3** — `labelFor()` renders field keys through `context/ontology_nodes.csv`.
- **R-5** — nothing in the model carries a secret; `HttpAdapterOptions.headers`
  is the only place a credential passes, and it never reaches a screen.
- **SO-7 / SO-8** — `releaseProgress()` counts one SME and one technical
  `GOOD TO GO` on the current build; a tag on any other build is `SUPERSEDED`
  and its user returns to the pending list.
- **NS-3** — `deriveNextSteps()` assigns severity by the stated precedence.

## Develop

```bash
cd playground
npm ci
npm run dev        # the harness at http://localhost:5173 — fixtures: claims, technical, guest, empty
npm run check      # lint, typecheck, tests, build
```

The harness mounts the playground on the Claims Triage fixture through the
memory adapter, with a bar to switch fixture. `?fixture=empty` is the A8
state; `?fixture=guest` is the time-boxed guest link (AC-3).

`npm run build` writes `dist/playground.js` (ESM, React external, about 32 KiB
gzip), `dist/playground.css` (the design system plus the playground layer) and
`dist/types/`.

## Layout

```
playground/
  src/
    Playground.tsx        the root component: adapter, user, navigation
    mount.tsx             mountPlayground() for non-React hosts
    index.ts              the public surface
    model/                vocabulary, types, adapter interface, format, derive
    adapters/             memory (reference), http (JSON contract)
    precord/              csv reader, readSolutionSpec()
    ui/chrome/            Shell, Rail, PageHeader
    ui/primitives/        Pill, Tag, FidelityChip, StatTile, Seg, Check, Code, DropZone, Empty …
    ui/screens/           one file per screen
    ui/review/            the embedded review screen (WC-6), also exported
    fixtures/             claimsTriage, emptySolution
    styles/               design-system.css (verbatim from the package), playground.css (layout layer)
    dev/                  the harness
  test/                   vitest + testing-library
```

## Deviations from the wireframes

Listed here as A10 asks.

1. The rail carries a small SME / Technical switch under the user's role, because
   AC-2 says the type is changeable and the wireframes show no other control for
   it. A guest link does not get it.
2. The as-is strip draws arrows only between steps; the wireframe's trailing
   arrow after the fifth box is an artefact of wrapping.
3. The reimagined card for a not-built agent shows the reason from the build
   record in full (*The settlement letter template was not supplied*) rather
   than the wireframe's shortened *Template not supplied*.
4. Open items name every mocked integration the probe found, so the fixture's
   item reads *Document store, Repair cost index and Payments API are mocked*;
   the wireframe names two of the three.
5. The threshold open item is worded from the register (*fields left empty is
   0.12, above the 0.10 threshold*) rather than hand-written as a percentage.
6. Performance shows a not-built agent's greyed row, and also a built agent
   with no threshold as a greyed *No threshold* row — the requirement is silent
   on that case and R-1 argues for saying so.
7. Overview's `EVALS PASSING` counts thresholds with a result, so `3 of 4` in
   the fixture matches the wireframe; an agent with no threshold does not
   count.
8. Solution Status opens the API detail card on the first integration that is
   not live; the wireframe shows Payments API selected with no stated rule.
9. Run to the end pauses at an `override` checkpoint only when the user is
   stepping one step at a time; running to the end passes it, as WC-5 says.
10. Walk a case can start on an eval case that the development set does not
    hold (PF-3 opens `SC-007`); its description is the failing reason.
11. OV-2 says the reimagined process is *a row of cards*, and the wireframe
    shows six. The cards wrap into further rows once there are more than the
    width holds, and the strip scrolls vertically past the height of the
    screen. A single row shared between twenty-four steps gives each card about
    30px, which shows the shape of the process and none of its content; a
    six-step process still fills one row exactly as the wireframe draws it.

## Not in this version (§8)

No code editor, traces or prompt inspector; no production console; no Precord
editor; no eval authoring; no responsive layout (the page is a fixed 1240px);
no platform-hosted playground without a deployment; no iframe embedding of the
review screen in a client system.
